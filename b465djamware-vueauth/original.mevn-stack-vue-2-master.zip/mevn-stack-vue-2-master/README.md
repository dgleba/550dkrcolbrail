# Securing MEVN Stack (Vue.js 2) Web Application using Passport

This source code is part of [Securing MEVN Stack (Vue.js 2) Web Application using Passport](https://www.djamware.com/post/5ac8338780aca714d19d5b9e/securing-mevn-stack-vuejs-2-web-application-using-passport)

To run locally:
* Run MongoDB server
* Clone this repository
* Run `npm install`
* Run `npm start`
